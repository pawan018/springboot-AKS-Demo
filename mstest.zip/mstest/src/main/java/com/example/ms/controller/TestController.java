package com.example.ms.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class TestController {
	
	
	@GetMapping("/test")
    public String testData()
    {
       
        return  "Welcome to the world of cloud native";
    }

}
